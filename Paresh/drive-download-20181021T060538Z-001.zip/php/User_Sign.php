<head>
	<link rel="stylesheet" id="linkh" href="../Stylesheets/header.css" />
	<link rel="stylesheet" id="linkn" href="../Stylesheets/navigation.css" />
	<style>
		#usr{
	
	background: lightgreen;
	color: green;
	//font-weight:bold;
	border-top-right-radius: 30px;
	-webkit-border-bottom-right-radius: 30px;
}
	</style>
</head>

<?php
	

	include("../Pages/Header.html");
	include("../Pages/User_Sign.html");
	include("../Pages/Footer.html");

	
?>