<head>
	<link rel="stylesheet" id="linkh" href="../Stylesheets/header.css" />
	<link rel="stylesheet" id="linkn" href="../Stylesheets/navigation.css" />
	
</head>

<?php
	

	include("../Pages/Header.html");
	include("../Pages/User_Registration.html");
	include("../Pages/Footer.html");

	
?>