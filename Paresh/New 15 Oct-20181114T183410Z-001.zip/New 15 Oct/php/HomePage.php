<head>
	<link rel="stylesheet" id="linkh" href="../Stylesheets/header.css" />
	<link rel="stylesheet" id="linkn" href="../Stylesheets/navigation.css" />
	<style>
		#home{

			background: rgba(135,206,250,0.3);
			color: blue;
			//font-weight:bold;
			border-top-right-radius: 30px;
			-webkit-border-bottom-right-radius: 30px;
		}
	</style>
</head>


<?php


	include("../Pages/Header.html");
	include("../Pages/Homepage.html");
	include("../Pages/Footer.html");


?>